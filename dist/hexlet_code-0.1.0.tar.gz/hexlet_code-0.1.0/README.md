### Hexlet tests and linter status:
[![Actions Status](https://github.com/kswonder/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/kswonder/python-project-49/actions)

<a href="https://codeclimate.com/github/kswonder/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/92fbe985c2a07effc397/maintainability" /></a>